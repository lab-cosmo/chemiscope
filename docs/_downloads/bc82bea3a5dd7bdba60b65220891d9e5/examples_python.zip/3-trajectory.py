"""
Trajectory plotting
===================

This example demonstrates the visualization of trajectory data. It also includes
visualization of atomic forces.

The same parameters can be used with :py:func:`chemiscope.show` to visualize an
interactive widget in a Jupyter notebook.
"""

# %%
#

import ase.io
import numpy as np

import chemiscope


# %%
#
# Load structures and properties
structures = ase.io.read("data/trajectory.xyz", ":")

properties = {
    # concise definition of a property, with just an array and the type
    # inferred by the size
    "index": np.arange(len(structures)),
    # an example of the verbose definition
    "energy": {
        "target": "structure",
        "values": [structure.info["dftb_energy_eV"] for structure in structures],
        "units": "eV",
        "description": "potential energy, computed with DFTB+",
    },
}


# %%
#
# Create a visualization and save it as a file that can be viewed at
# `<chemiscope.org>`_:

chemiscope.write_input(
    "trajectory-md.json.gz",
    # dataset metadata can also be included, to provide a self-contained description
    # of the data, authors and references
    metadata={
        "name": "Allyl alcohol MD trajectory.",
        "description": (
            "This dataset contains data from a DFTB+ trajectory of allyl alcohol."
        ),
        "authors": ["The chemiscope developers"],
        "references": [
            (
                "G. Fraux, R. Cersonsky, and M. Ceriotti, "
                '"Chemiscope: interactive structure-property explorer for materials '
                'and molecules," JOSS 5(51), 2117 (2020).'
            )
        ],
    },
    structures=structures,
    properties=properties,
    # visualize forces as vectors
    shapes={
        "forces": chemiscope.ase_vectors_to_arrows(
            structures, "dftb_forces_eV_per_Ang", scale=1, radius=0.15
        )
    },
    settings={  # these are reasonable settings for trajectory visualization
        "structure": [
            {
                "keepOrientation": True,
                "playbackDelay": 100,
                "shape": "forces",  # visualize force vectors
            }
        ],
        "map": {
            "joinPoints": True,
        },
    },
)

# %%
#
# The file can also be viewed in a notebook. Use `chemiscope.show` above to bypass the
# creation of a JSON file and directly create a viewer.

chemiscope.show_input("trajectory-md.json.gz")
